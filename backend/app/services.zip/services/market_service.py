import re
import time as _time
from datetime import date, datetime
from concurrent.futures import TimeoutError as FutureTimeoutError

import yfinance as yf

from app.cache import cache_get, cache_set
from app.jobs import enqueue_job
from app.market.pipeline import YahooFinancePipeline

pipeline = YahooFinancePipeline()

FRESH_TTL_SECONDS = 60          # 1 minute fresh cache window
FALLBACK_TTL_SECONDS = 86400    # 24 hour last-known-good fallback window

INDICES_CACHE_KEY = "market:indices"
_INDICES_TTL = 300            # 5 minutes
_INDICES_FALLBACK_TTL = 30    # Retry sooner if zero results returned

_TICKER_RE = re.compile(r"^[A-Za-z0-9\.\^=\-]{1,15}$")

INDICES = [
    {"name": "S&P 500",       "ticker": "^GSPC"},
    {"name": "NASDAQ",        "ticker": "^IXIC"},
    {"name": "DOW",           "ticker": "^DJI"},
    {"name": "AAPL",          "ticker": "AAPL"},
    {"name": "MSFT",          "ticker": "MSFT"},
    {"name": "NVDA",          "ticker": "NVDA"},
    {"name": "AMZN",          "ticker": "AMZN"},
    {"name": "TSLA",          "ticker": "TSLA"},
    {"name": "USD/INR",      "ticker": "INR=X"},
    {"name": "GOLD",          "ticker": "GC=F"},
    {"name": "NIFTY 50",      "ticker": "^NSEI"},
    {"name": "SENSEX",        "ticker": "^BSESN"},
    {"name": "NIFTY IT",      "ticker": "^CNXIT"},
    {"name": "NIFTY PHARMA",  "ticker": "^CNXPHARMA"},
]


class MarketError(Exception):
    """Raised when a market data request can't be fulfilled.
    Carries the HTTP status code the route should respond with."""
    def __init__(self, message: str, status_code: int = 400):
        super().__init__(message)
        self.message = message
        self.status_code = status_code


# -----------------------------------------------------------------------------
# Helpers: Timeout Wrapping & Input Validation
# -----------------------------------------------------------------------------

def _fetch_with_timeout(func, timeout: float = 10):
    """Executes a blocking function using the job pool with a hard timeout."""
    future = enqueue_job(func)
    try:
        return future.result(timeout=timeout)
    except (FutureTimeoutError, Exception):
        return None


def _validate_ticker(ticker: str) -> str:
    """Validates ticker format to prevent malformed queries."""
    if not ticker or not _TICKER_RE.match(ticker):
        raise MarketError(f"Invalid ticker format: '{ticker}'", 400)
    return ticker.upper()


def _validate_date_range(start: str, end: str) -> tuple[str, str]:
    """Validates date formats, chronological ordering, and prevents future dates."""
    if not start or not end:
        raise MarketError("Query params 'start' and 'end' are required (YYYY-MM-DD)", 400)

    try:
        start_date = datetime.strptime(start, "%Y-%m-%d").date()
        end_date = datetime.strptime(end, "%Y-%m-%d").date()
    except ValueError:
        raise MarketError("'start' and 'end' must be valid dates in YYYY-MM-DD format", 400)

    if start_date >= end_date:
        raise MarketError("'start' must be earlier than 'end'", 400)

    if end_date > date.today():
        raise MarketError("'end' cannot be in the future", 400)

    return start, end


# -----------------------------------------------------------------------------
# Core Market Services
# -----------------------------------------------------------------------------

def get_price_with_staleness(ticker: str) -> dict:
    """
    Returns {"price": float | None, "is_stale": bool, "source": "live" | "cache" | "unavailable"}.
    Never raises. On live-fetch failure, falls back to the last known good price
    (if any) and marks it stale.
    """
    if not ticker:
        return {"price": None, "is_stale": True, "source": "unavailable"}

    ticker = ticker.upper()
    fresh_key = f"price:fresh:{ticker}"
    fallback_key = f"price:last_known:{ticker}"

    # Tier 1: Check fresh cache
    cached_fresh = cache_get(fresh_key)
    if cached_fresh is not None:
        return {"price": cached_fresh["price"], "is_stale": False, "source": "cache"}

    # Live fetch attempt
    live_price = _fetch_with_timeout(lambda: pipeline.get_current_price(ticker), timeout=8)

    if live_price is not None and live_price > 0:
        payload = {"price": float(live_price), "fetched_at": _time.time()}
        cache_set(fresh_key, payload, FRESH_TTL_SECONDS)
        cache_set(fallback_key, payload, FALLBACK_TTL_SECONDS)
        return {"price": float(live_price), "is_stale": False, "source": "live"}

    # Tier 2: Live fetch failed -> Fallback to last known good price
    cached_fallback = cache_get(fallback_key)
    if cached_fallback is not None:
        return {"price": cached_fallback["price"], "is_stale": True, "source": "cache"}

    return {"price": None, "is_stale": True, "source": "unavailable"}


def current_price(ticker: str) -> dict:
    """
    Updated route handler for market API that uses resilient lookup
    and surfaces staleness metadata to the caller.
    """
    ticker = _validate_ticker(ticker)
    info = get_price_with_staleness(ticker)
    if info["price"] is None:
        raise MarketError(f"Could not fetch price for '{ticker}'", 404)
    return {
        "ticker": ticker,
        "price": info["price"],
        "is_stale": info["is_stale"],
        "source": info["source"],
    }


def stock_info(ticker: str) -> dict:
    ticker = _validate_ticker(ticker)
    info = _fetch_with_timeout(lambda: pipeline.get_stock_info(ticker), timeout=10)
    if info is None or not info.get("company_name"):
        raise MarketError(f"Ticker '{ticker}' not found or provider unavailable", 404)
    return info


def price_history(ticker: str, start: str, end: str) -> dict:
    ticker = _validate_ticker(ticker)
    start, end = _validate_date_range(start, end)

    dataset = _fetch_with_timeout(lambda: pipeline.build_dataset(ticker, start, end), timeout=20)
    if dataset is None:
        raise MarketError("Market data provider unavailable, please try again", 503)

    try:
        history = dataset["stock_history"]
        records = history[["Date", "Open", "High", "Low", "Close", "Volume", "Daily_Return"]].copy()
        records["Date"] = records["Date"].astype(str)
    except Exception:
        raise MarketError(f"No price history available for '{ticker}' in this range", 404)

    return {
        "ticker": ticker,
        "start": start,
        "end": end,
        "rows": len(records),
        "history": records.to_dict(orient="records"),
    }


def benchmark(start: str, end: str) -> dict:
    start, end = _validate_date_range(start, end)

    data = _fetch_with_timeout(lambda: pipeline.get_benchmark_data(start, end), timeout=20)
    if data is None:
        raise MarketError("Market data provider unavailable, please try again", 503)

    try:
        data = pipeline.clean_data(data)
        data = pipeline.calculate_returns(data)
        records = data[["Date", "Close", "Daily_Return"]].copy()
        records["Date"] = records["Date"].astype(str)
    except Exception:
        raise MarketError("No benchmark data available for this range", 404)

    return {
        "ticker": "^GSPC",
        "start": start,
        "end": end,
        "rows": len(records),
        "benchmark": records.to_dict(orient="records"),
    }


def indices() -> list:
    """Price + % change for tracked indices using shared Redis cache."""
    cached = cache_get(INDICES_CACHE_KEY)
    if cached is not None:
        return cached

    results = []
    for entry in INDICES:
        try:
            hist = _fetch_with_timeout(
                lambda t=entry["ticker"]: yf.Ticker(t).history(period="5d"),
                timeout=8
            )
            if hist is None or hist.empty or len(hist) < 2:
                continue
            today_close = float(hist["Close"].iloc[-1])
            prev_close = float(hist["Close"].iloc[-2])
            if prev_close == 0.0:
                continue

            change_pct = (today_close - prev_close) / prev_close * 100
            price_str = f"{today_close:,.0f}" if today_close >= 1000 else f"{today_close:,.2f}"
            change_str = f"{'+' if change_pct >= 0 else ''}{change_pct:.2f}%"

            results.append({
                "name": entry["name"],
                "ticker": entry["ticker"],
                "price": price_str,
                "change": change_str,
                "up": change_pct >= 0,
            })
        except Exception:
            continue

    ttl = _INDICES_TTL if results else _INDICES_FALLBACK_TTL
    cache_set(INDICES_CACHE_KEY, results, ttl)
    return results


def search(q: str) -> dict:
    q = (q or "").strip()
    if len(q) < 2:
        return {"results": []}

    try:
        result = _fetch_with_timeout(lambda: yf.Search(q, max_results=10), timeout=5)
        if not result or not getattr(result, "quotes", None):
            return {"results": []}

        quotes = result.quotes or []
        formatted = [
            {
                "ticker": r.get("symbol"),
                "name": r.get("longname") or r.get("shortname"),
                "exchange": r.get("exchDisp"),
                "sector": r.get("sectorDisp"),
                "type": r.get("typeDisp"),
            }
            for r in quotes
            if r.get("symbol") and r.get("quoteType") == "EQUITY"
        ]
        return {"results": formatted[:8]}
    except Exception:
        return {"results": []}